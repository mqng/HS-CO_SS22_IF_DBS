import java.sql.*;
import java.util.Scanner;

class Flug {
    public static void main(String args[]) {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wwfakng", "root", "root");
            
            Scanner sc = new Scanner(System.in);
            
            System.out.print("Kennzeichen der Maschine eingeben: ");
            String kennzeichen = sc.nextLine();
            
            System.out.print("Flugnummer eingeben: ");
            int flugnummer = Integer.parseInt(sc.nextLine());

            System.out.print("Wochentag eingeben (Ausgeschrieben): ");
            String wochentag = sc.nextLine();

            Statement stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO Flug VALUES ('"+kennzeichen+"',"+flugnummer+",'"+wochentag+"')");
            ResultSet rs = stmt.executeQuery("SELECT * FROM Flug");
            while(rs.next())
                System.out.println(rs.getString(1) + " " + rs.getString(2) + " "+ rs.getString(3));
            sc.close();
            con.close();
        } catch(Exception e) {System.out.println(e);}
    } 
}
